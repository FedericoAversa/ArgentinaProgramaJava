public class EjerciciosClase1 {
    public static void main(String[] args) {

        int numeroInicio = 5;
        int numeroFin = 14;

        while (numeroInicio <= numeroFin) {
            System.out.println(numeroInicio);
            numeroInicio = numeroInicio + 1;
        }
    }
}