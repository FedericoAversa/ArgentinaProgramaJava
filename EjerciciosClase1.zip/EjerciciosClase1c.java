public class EjerciciosClase1c {
    public static void main(String[] args) {

        int numeroInicio = 5;
        int numeroFin = 14;
        boolean mostrarPares = false;

        for (int indice = numeroInicio; indice <= numeroFin; indice++) {
            if(indice%2 == 0 && mostrarPares){
                System.out.println("Es Par: " + indice);
            } else if (indice%2 != 0 && !mostrarPares) {
                System.out.println("Es Impar: " + indice);
            }
        }
    }
}
