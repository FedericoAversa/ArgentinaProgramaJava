public class EjerciciosClase1b {
    public static void main(String[] args) {

        int numeroInicio = 5;
        int numeroFin = 14;

        for (int indice = numeroInicio; indice <= numeroFin; indice++) {
            if(indice%2 == 0){
                System.out.println("Es Par: " + indice);
            }
        }
    }
}

