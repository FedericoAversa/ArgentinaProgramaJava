package EjerciciosClase1;
public class Punto2 {
    public static void main(String[] args){
        float ingresosMensuales = 0;
        int cantidadVehiculos = 0;
        float antiguedadVehiculos = 0f;
        int cantidadInmuebles = 0;
        boolean lujos = false;

        if((ingresosMensuales >=572386.60) || (cantidadVehiculos>3) && (antiguedadVehiculos<5) || (cantidadInmuebles>=3) || (lujos)){
            System.out.println("Usted pertenece al segmento de Ingresos Altos.");
        } else if ((ingresosMensuales >163539) || (cantidadVehiculos>1 && cantidadVehiculos<3) && (antiguedadVehiculos>0 && antiguedadVehiculos<3) || (cantidadInmuebles<=2 && cantidadInmuebles>3) && (!lujos)) {
            System.out.println("Usted pertenece al segmento de Ingresos Medios.");
        } else if ((ingresosMensuales <163539) || (cantidadVehiculos==1) && (cantidadInmuebles<=1) && (!lujos)) {
            System.out.println("Usted pertenece al segmento de Ingresos Bajos.");
        }
    }
}
